import { useState, useRef, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatbotProps {
  onClose: () => void;
}

export default function Chatbot({ onClose }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi! I'm Collins' AI assistant. I can answer questions about his skills, projects, and availability in cybersecurity and database development. How can I help you?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const logChatMessage = useMutation(api.portfolio.logChatMessage);

  const faqResponses: Record<string, string> = {
    skills: "Collins is proficient in Oracle SQL, Java Programming, Network Administration, Cybersecurity, Windows/Linux OS configuration, Database Development, Active Directory, and Google Analytics. He has strong expertise in system infrastructure and technical troubleshooting.",
    
    projects: "Collins has worked on various projects including Server Administration with Active Directory, Network Administration using Packet Tracer, Database Development with Oracle SQL for jail management systems, and Operating Systems installation and configuration. You can view all his projects in the Projects section above.",
    
    experience: "Collins has professional experience as a Front Desk Associate at Amazon (November 2023) and Mobile Communications Assistant at Future Care (August 2021). He's currently a Junior Undergraduate at Bowie State University studying Computer Technology with a focus on cybersecurity.",
    
    availability: "Collins is currently seeking opportunities in IT and cybersecurity fields. He's particularly interested in roles involving database development, system infrastructure, and network security. Feel free to reach out through the contact form!",
    
    education: "Collins is currently a Junior Undergraduate studying Computer Technology at Bowie State University, specializing in cybersecurity and database development. He graduated from Milford Mill Academy with honors and participated in the P.L.T.W Gateway to Technology Magnet program.",
    
    contact: "You can reach Collins through the contact form on this website, email him at Onokalacollins17@gmail.com, call him at 443-345-6349, or connect with him on LinkedIn. He typically responds within 24 hours.",
    
    technologies: "Collins works with Oracle SQL, Java, Windows and Linux operating systems, Active Directory, network administration tools like Packet Tracer, virtualization technologies, and various cybersecurity tools. He's always learning new technologies in the cybersecurity field.",
    
    location: "Collins is based in Maryland, USA, and is open to both local and remote opportunities in cybersecurity and database development.",

    cybersecurity: "Collins has a strong focus on cybersecurity with experience in system infrastructure, network security, and technical troubleshooting. He's currently studying cybersecurity as part of his Computer Technology program at Bowie State University.",

    database: "Collins has extensive experience in database development, particularly with Oracle SQL. He developed a comprehensive jail management database system with proper table structures, primary and foreign keys, and data integrity constraints.",
  };

  const getBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes("hello") || message.includes("hi") || message.includes("hey")) {
      return "Hello! Nice to meet you. I can help you learn more about Collins' background in cybersecurity, database development, and his technical projects. What would you like to know?";
    }
    
    if (message.includes("skill") || message.includes("technology") || message.includes("tech")) {
      return faqResponses.skills;
    }
    
    if (message.includes("project") || message.includes("work") || message.includes("portfolio")) {
      return faqResponses.projects;
    }
    
    if (message.includes("experience") || message.includes("background") || message.includes("career")) {
      return faqResponses.experience;
    }
    
    if (message.includes("available") || message.includes("hire") || message.includes("job") || message.includes("opportunity")) {
      return faqResponses.availability;
    }
    
    if (message.includes("education") || message.includes("degree") || message.includes("university") || message.includes("study")) {
      return faqResponses.education;
    }
    
    if (message.includes("contact") || message.includes("reach") || message.includes("email") || message.includes("phone")) {
      return faqResponses.contact;
    }
    
    if (message.includes("location") || message.includes("where") || message.includes("based")) {
      return faqResponses.location;
    }

    if (message.includes("cybersecurity") || message.includes("security") || message.includes("cyber")) {
      return faqResponses.cybersecurity;
    }

    if (message.includes("database") || message.includes("sql") || message.includes("oracle")) {
      return faqResponses.database;
    }
    
    if (message.includes("thank") || message.includes("thanks")) {
      return "You're welcome! Is there anything else you'd like to know about Collins' background in cybersecurity, database development, or his technical experience?";
    }
    
    // Default response
    return "I can help you with information about Collins' skills in cybersecurity and database development, his projects, experience, availability, education, and contact details. Try asking about any of these topics, or feel free to browse the portfolio sections above!";
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(async () => {
      const botResponse = getBotResponse(inputValue);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse,
        isBot: true,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);

      // Log the conversation
      try {
        await logChatMessage({
          question: inputValue,
          answer: botResponse,
          sessionId: `session_${Date.now()}`,
        });
      } catch (error) {
        console.error("Failed to log chat message:", error);
      }
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-black/80 backdrop-blur-md rounded-2xl border border-white/20 w-full max-w-md h-[600px] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <div>
              <h3 className="text-white font-semibold">Collins' Assistant</h3>
              <p className="text-gray-400 text-sm">Online</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors duration-300"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isBot ? "justify-start" : "justify-end"}`}
            >
              <div
                className={`max-w-[80%] p-3 rounded-2xl ${
                  message.isBot
                    ? "bg-gray-700 text-white"
                    : "bg-gradient-to-r from-cyan-500 to-purple-500 text-white"
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-700 text-white p-3 rounded-2xl">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-white/10">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me about Collins' cybersecurity skills, projects, or experience..."
              className="flex-1 px-4 py-2 bg-black/30 border border-gray-600 rounded-full text-white placeholder-gray-400 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition-all duration-300"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim()}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 disabled:from-gray-600 disabled:to-gray-700 text-white rounded-full transition-all duration-300 disabled:cursor-not-allowed"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
