import { useState, useEffect } from "react";

interface QRCodeGeneratorProps {
  onClose: () => void;
}

export default function QRCodeGenerator({ onClose }: QRCodeGeneratorProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [selectedUrl, setSelectedUrl] = useState("portfolio");

  const urls = {
    portfolio: window.location.href,
    resume: `${window.location.origin}/resume.html`,
    github: "https://github.com/johndoe",
    linkedin: "https://linkedin.com/in/johndoe",
    contact: `${window.location.origin}#contact`,
  };

  useEffect(() => {
    generateQRCode();
  }, [selectedUrl]);

  const generateQRCode = () => {
    const url = urls[selectedUrl as keyof typeof urls];
    // Using QR Server API for QR code generation
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}`;
    setQrCodeUrl(qrUrl);
  };

  const downloadQRCode = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `qr-code-${selectedUrl}.png`;
    link.click();
  };

  const copyToClipboard = () => {
    const url = urls[selectedUrl as keyof typeof urls];
    navigator.clipboard.writeText(url);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-black/80 backdrop-blur-md rounded-2xl border border-white/20 w-full max-w-md p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-white">QR Code Generator</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors duration-300"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* URL Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Select what to share:
          </label>
          <div className="space-y-2">
            {Object.entries(urls).map(([key, url]) => (
              <label key={key} className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="radio"
                  name="url"
                  value={key}
                  checked={selectedUrl === key}
                  onChange={(e) => setSelectedUrl(e.target.value)}
                  className="text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-white capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
              </label>
            ))}
          </div>
        </div>

        {/* QR Code Display */}
        <div className="text-center mb-6">
          <div className="bg-white p-4 rounded-lg inline-block mb-4">
            {qrCodeUrl && (
              <img
                src={qrCodeUrl}
                alt="QR Code"
                className="w-64 h-64 mx-auto"
              />
            )}
          </div>
          <p className="text-gray-400 text-sm">
            Scan this QR code to access: {selectedUrl}
          </p>
        </div>

        {/* URL Display */}
        <div className="mb-6">
          <div className="bg-black/30 border border-gray-600 rounded-lg p-3 flex items-center justify-between">
            <span className="text-gray-300 text-sm truncate flex-1 mr-2">
              {urls[selectedUrl as keyof typeof urls]}
            </span>
            <button
              onClick={copyToClipboard}
              className="text-cyan-400 hover:text-cyan-300 transition-colors duration-300"
              title="Copy URL"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3">
          <button
            onClick={downloadQRCode}
            className="flex-1 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold rounded-lg transition-all duration-300 hover:scale-105 flex items-center justify-center"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Download
          </button>
          
          <button
            onClick={copyToClipboard}
            className="flex-1 px-4 py-2 border-2 border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white font-semibold rounded-lg transition-all duration-300 hover:scale-105 flex items-center justify-center"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            Copy URL
          </button>
        </div>

        {/* Instructions */}
        <div className="mt-6 p-4 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-lg border border-cyan-500/20">
          <h4 className="text-cyan-300 font-semibold mb-2">How to use:</h4>
          <ul className="text-gray-400 text-sm space-y-1">
            <li>• Select what you want to share from the options above</li>
            <li>• Download the QR code image or copy the URL</li>
            <li>• Share the QR code on business cards, resumes, or presentations</li>
            <li>• Others can scan it with their phone camera to visit the link</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
