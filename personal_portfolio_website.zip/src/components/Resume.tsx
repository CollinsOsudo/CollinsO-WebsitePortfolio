import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export default function Resume() {
  const [isUploading, setIsUploading] = useState(false);
  const resumeFile = useQuery(api.portfolio.getResumeFile);
  const generateUploadUrl = useMutation(api.portfolio.generateResumeUploadUrl);
  const saveResumeFile = useMutation(api.portfolio.saveResumeFile);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (file.type !== "application/pdf") {
      toast.error("Please upload a PDF file only.");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB.");
      return;
    }

    setIsUploading(true);
    try {
      // Step 1: Get upload URL
      const postUrl = await generateUploadUrl();
      
      // Step 2: Upload file
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      
      const json = await result.json();
      if (!result.ok) {
        throw new Error(`Upload failed: ${JSON.stringify(json)}`);
      }
      
      // Step 3: Save file reference
      await saveResumeFile({
        storageId: json.storageId,
        filename: file.name,
      });
      
      toast.success("Resume uploaded successfully!");
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("Failed to upload resume. Please try again.");
    } finally {
      setIsUploading(false);
      // Reset file input
      event.target.value = "";
    }
  };

  const handleDownloadPDF = () => {
    if (resumeFile?.url) {
      const link = document.createElement('a');
      link.href = resumeFile.url;
      link.download = resumeFile.filename || 'Collins_Onokala_Resume.pdf';
      link.click();
    } else {
      toast.error("No resume file available for download.");
    }
  };

  const handleViewHTML = () => {
    window.open('/resume.html', '_blank');
  };

  return (
    <section id="resume" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Resume
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Download my resume or view it online to learn more about my professional experience and qualifications in cybersecurity and database development.
          </p>
        </div>

        <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10">
          {/* Resume Upload Section */}
          <div className="mb-8 p-6 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-lg border border-cyan-500/20">
            <h3 className="text-xl font-bold text-white mb-4">Upload Resume</h3>
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <input
                type="file"
                accept=".pdf"
                onChange={handleFileUpload}
                disabled={isUploading}
                className="flex-1 px-4 py-2 bg-black/30 border border-gray-600 rounded-lg text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-500 file:text-white hover:file:bg-cyan-600 disabled:opacity-50"
              />
              {isUploading && (
                <div className="flex items-center text-cyan-400">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-cyan-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Uploading...
                </div>
              )}
            </div>
            <p className="text-gray-400 text-sm mt-2">
              Upload a PDF version of your resume (max 5MB). This will replace any existing resume file.
            </p>
            {resumeFile && (
              <div className="mt-4 p-3 bg-green-500/20 border border-green-500/30 rounded-lg">
                <p className="text-green-300 text-sm">
                  ✅ Current resume: {resumeFile.filename} (uploaded {new Date(resumeFile.uploadedAt).toLocaleDateString()})
                </p>
              </div>
            )}
          </div>

          {/* Resume Preview */}
          <div className="bg-white text-gray-900 rounded-lg p-8 mb-8 shadow-2xl">
            <div className="text-center mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Collins Onokala</h1>
              <p className="text-lg text-gray-600 mb-2">Cybersecurity & Database Development Specialist</p>
              <div className="flex justify-center space-x-4 text-sm text-gray-600">
                <span>📧 Onokalacollins17@gmail.com</span>
                <span>📱 443-345-6349</span>
                <span>🔗 LinkedIn Profile</span>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-3 border-b-2 border-cyan-500 pb-1">Professional Experience</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <h4 className="font-semibold">Front Desk Associate</h4>
                    <p className="text-gray-600">Amazon | November 2023</p>
                    <ul className="list-disc list-inside text-gray-700 mt-1">
                      <li>Managed office operations and clerical support</li>
                      <li>Monitored office supplies to ensure efficiency</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold">Mobile Communications Assistant</h4>
                    <p className="text-gray-600">Future Care | August 2021</p>
                    <ul className="list-disc list-inside text-gray-700 mt-1">
                      <li>Drafted and managed internal communications</li>
                      <li>Assisted senior leadership with strategic messaging</li>
                    </ul>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-gray-900 mb-3 mt-6 border-b-2 border-purple-500 pb-1">Key Projects</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <h4 className="font-semibold">Server Administration</h4>
                    <p className="text-gray-700">Designed infrastructure using VMs and Active Directory</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Database Development</h4>
                    <p className="text-gray-700">Developed jail management database using Oracle SQL</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Network Administration</h4>
                    <p className="text-gray-700">Engineered tree network topology using Packet Tracer</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-3 border-b-2 border-green-500 pb-1">Technical Skills</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <h4 className="font-semibold">Programming</h4>
                    <p className="text-gray-700">Java, Oracle SQL</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Systems</h4>
                    <p className="text-gray-700">Windows, Linux, Active Directory</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Networking</h4>
                    <p className="text-gray-700">Network Administration, Troubleshooting</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Security</h4>
                    <p className="text-gray-700">Cybersecurity, System Infrastructure</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Analytics</h4>
                    <p className="text-gray-700">Google Analytics, Data Collection</p>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-gray-900 mb-3 mt-6 border-b-2 border-pink-500 pb-1">Education</h3>
                <div className="text-sm">
                  <h4 className="font-semibold">Computer Technology</h4>
                  <p className="text-gray-600">Bowie State University | Junior Undergraduate</p>
                  <p className="text-gray-700">Focus: Cybersecurity & Database Development</p>
                  
                  <h4 className="font-semibold mt-3">High School Diploma</h4>
                  <p className="text-gray-600">Milford Mill Academy</p>
                  <p className="text-gray-700">P.L.T.W Gateway to Technology, Honor Roll</p>
                </div>
              </div>
            </div>
          </div>

          {/* Download Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={handleDownloadPDF}
              disabled={!resumeFile}
              className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold rounded-full transition-all duration-300 hover:scale-105 disabled:scale-100 flex items-center justify-center disabled:cursor-not-allowed"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              {resumeFile ? "Download PDF" : "No PDF Available"}
            </button>
            
            <button
              onClick={handleViewHTML}
              className="px-8 py-3 border-2 border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white font-semibold rounded-full transition-all duration-300 hover:scale-105 flex items-center justify-center"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View Online
            </button>
          </div>

          {/* Instructions */}
          <div className="mt-8 p-4 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-lg border border-cyan-500/20">
            <h4 className="text-cyan-300 font-semibold mb-2">How to upload your resume:</h4>
            <ul className="text-gray-400 text-sm space-y-1">
              <li>• Create a PDF version of your resume using Word, Google Docs, or any resume builder</li>
              <li>• Click "Choose File" above and select your PDF (max 5MB)</li>
              <li>• The file will be uploaded automatically and replace any existing resume</li>
              <li>• Visitors can then download your actual resume using the "Download PDF" button</li>
            </ul>
          </div>

          {/* QR Code for Resume */}
          <div className="text-center mt-8">
            <p className="text-gray-400 mb-4">Scan QR code to view resume on mobile:</p>
            <div className="inline-block p-4 bg-white rounded-lg">
              <div className="w-32 h-32 bg-gray-200 flex items-center justify-center text-gray-500 text-xs">
                QR Code for Resume
                <br />
                (Generated dynamically)
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
