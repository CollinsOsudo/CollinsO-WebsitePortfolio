export default function About() {
  const skills = [
    { name: "Oracle SQL", level: 90 },
    { name: "Java Programming", level: 85 },
    { name: "Network Administration", level: 80 },
    { name: "Cybersecurity", level: 85 },
    { name: "Windows/Linux OS", level: 90 },
    { name: "Database Development", level: 88 },
    { name: "Active Directory", level: 75 },
    { name: "Google Analytics", level: 70 },
  ];

  const experiences = [
    {
      title: "Front Desk Associate",
      company: "Amazon",
      period: "November 2023",
      description: "Managed office operations, clerical support, and monitored office supplies to ensure efficiency."
    },
    {
      title: "Mobile Communications Assistant",
      company: "Future Care",
      period: "August 2021",
      description: "Drafted and managed internal communications, website content, and mass media. Assisted senior leadership in conveying strategies and messages."
    }
  ];

  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              About Me
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            I'm a motivated Senior Undergrad with a focus on Cybersecurity and database development, 
            possessing a strong foundation in computer technology and IoT systems. I leverage my knowledge 
            of system infrastructure, database management, and technical troubleshooting to solve complex problems.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Skills */}
          <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10">
            <h3 className="text-2xl font-bold text-white mb-6">Technical Skills</h3>
            <div className="space-y-4">
              {skills.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300">{skill.name}</span>
                    <span className="text-cyan-400">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-purple-500 h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education */}
          <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10">
            <h3 className="text-2xl font-bold text-white mb-6">Education</h3>
            <div className="space-y-6">
              <div>
                <h4 className="text-lg font-semibold text-cyan-400">Computer Technology</h4>
                <p className="text-gray-300">Bowie State University</p>
                <p className="text-gray-400">Junior Undergraduate - In Progress</p>
                <p className="text-gray-400 mt-2">
                  Specializing in cybersecurity, database development, and IoT systems with a focus on 
                  system infrastructure and network security.
                </p>
              </div>
              
              <div>
                <h4 className="text-lg font-semibold text-cyan-400">High School Diploma</h4>
                <p className="text-gray-300">Milford Mill Academy</p>
                <p className="text-gray-400">Graduated</p>
                <p className="text-gray-400 mt-2">
                  Project Lead The Way (P.L.T.W) - Gateway to Technology Magnet Program. 
                  Honor Roll Recipient with Perfect Attendance.
                </p>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-cyan-400">STEM Camp</h4>
                <p className="text-gray-300">Northwest Academy</p>
                <p className="text-gray-400 mt-2">
                  Participated in intensive STEM program focusing on technology and engineering principles.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Experience */}
        <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10">
          <h3 className="text-2xl font-bold text-white mb-8">Professional Experience</h3>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div key={index} className="border-l-2 border-cyan-500 pl-6 relative">
                <div className="absolute w-4 h-4 bg-cyan-500 rounded-full -left-2 top-0"></div>
                <h4 className="text-xl font-semibold text-white">{exp.title}</h4>
                <p className="text-cyan-400 font-medium">{exp.company}</p>
                <p className="text-gray-400 text-sm mb-2">{exp.period}</p>
                <p className="text-gray-300">{exp.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Areas of Expertise */}
        <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-white/10 mt-12">
          <h3 className="text-2xl font-bold text-white mb-6">Areas of Expertise</h3>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              "Technical Support",
              "Programming (Java)",
              "Configuring & Installing OS (Windows & Linux)",
              "Networking",
              "Oracle SQL Database Development",
              "Troubleshooting & Problem Resolution",
              "Microsoft Office Suite",
              "Data Collection & Analytics",
              "Google Analytics"
            ].map((expertise, index) => (
              <div key={index} className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 px-3 py-2 rounded-lg border border-cyan-500/30 text-center">
                {expertise}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
