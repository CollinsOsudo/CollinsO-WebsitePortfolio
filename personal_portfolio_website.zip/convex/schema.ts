import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  contacts: defineTable({
    name: v.string(),
    email: v.string(),
    message: v.string(),
    timestamp: v.number(),
  }),
  chatMessages: defineTable({
    question: v.string(),
    answer: v.string(),
    timestamp: v.number(),
    sessionId: v.optional(v.string()),
  }),
  resumeFiles: defineTable({
    storageId: v.id("_storage"),
    filename: v.string(),
    uploadedAt: v.number(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
