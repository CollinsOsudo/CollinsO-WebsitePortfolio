import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const submitContact = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("contacts", {
      name: args.name,
      email: args.email,
      message: args.message,
      timestamp: Date.now(),
    });
    return { success: true };
  },
});

export const getContacts = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("contacts").order("desc").collect();
  },
});

export const logChatMessage = mutation({
  args: {
    question: v.string(),
    answer: v.string(),
    sessionId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("chatMessages", {
      question: args.question,
      answer: args.answer,
      timestamp: Date.now(),
      sessionId: args.sessionId,
    });
    return { success: true };
  },
});

// Resume upload functions
export const generateResumeUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveResumeFile = mutation({
  args: { 
    storageId: v.id("_storage"),
    filename: v.string(),
  },
  handler: async (ctx, args) => {
    // Delete any existing resume
    const existingResume = await ctx.db.query("resumeFiles").first();
    if (existingResume) {
      await ctx.db.delete(existingResume._id);
    }
    
    // Save new resume
    await ctx.db.insert("resumeFiles", {
      storageId: args.storageId,
      filename: args.filename,
      uploadedAt: Date.now(),
    });
    return { success: true };
  },
});

export const getResumeFile = query({
  args: {},
  handler: async (ctx) => {
    const resumeFile = await ctx.db.query("resumeFiles").first();
    if (!resumeFile) {
      return null;
    }
    
    const url = await ctx.storage.getUrl(resumeFile.storageId);
    return {
      ...resumeFile,
      url,
    };
  },
});
