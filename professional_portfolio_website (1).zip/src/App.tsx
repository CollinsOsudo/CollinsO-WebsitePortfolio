import { useState, useEffect } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { Toaster, toast } from "sonner";
import QRCode from "qrcode";
import "./portfolio.css";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  const messages = useQuery(api.portfolio.getChatMessages) || [];
  const sendMessage = useMutation(api.portfolio.sendMessage);
  const submitContact = useMutation(api.portfolio.submitContact);
  const getResumeUrl = useQuery(api.portfolio.getResumeUrl);

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setIsLoading(false), 1500);
    
    // Generate QR code
    const generateQR = async () => {
      try {
        const canvas = document.getElementById('qr-canvas') as HTMLCanvasElement;
        if (canvas) {
          await QRCode.toCanvas(canvas, window.location.origin, {
            width: 120,
            margin: 1,
            color: {
              dark: '#00ff41',
              light: '#ffffff'
            }
          });
        }
      } catch (error) {
        console.error('Error generating QR code:', error);
      }
    };
    
    if (!isLoading) {
      generateQR();
    }
  }, [isLoading]);

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    await sendMessage({ content: chatInput, sender: "user" });
    
    // Enhanced chatbot responses
    const botResponse = getBotResponse(chatInput);
    setTimeout(async () => {
      await sendMessage({ content: botResponse, sender: "bot" });
    }, 1000);

    setChatInput("");
  };

  const getBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes("skill") || lowerInput.includes("technology")) {
      return "I have expertise in Technical Support, Programming languages (Java), Oracle SQL, Networking, Microsoft Office Suite (6+ years experience), and Search Engine Optimization. I'm also experienced in configuring OS's and troubleshooting.";
    }
    if (lowerInput.includes("project") || lowerInput.includes("work")) {
      return "I've worked in various roles including Mobile Communications Assistant at Future Care where I drafted internal communications and assisted senior leadership, and Front Desk Support at Amazon managing office operations and clerical support.";
    }
    if (lowerInput.includes("experience") || lowerInput.includes("background")) {
      return "I'm a hard-working College Senior at Bowie State University with experience in IT support, database development, and IoT. I have hands-on experience from roles at Future Care and Amazon, plus military training through JROTC.";
    }
    if (lowerInput.includes("contact") || lowerInput.includes("hire") || lowerInput.includes("phone")) {
      return "You can reach me at 443-345-6349 or email me at Onokalacollins17@gmail.com. I'm currently available for IT and computer field opportunities!";
    }
    if (lowerInput.includes("education") || lowerInput.includes("school")) {
      return "I graduated from Milford Mill Academy and I'm currently a Senior at Bowie State University. I was also part of JROTC, Project Lead The Way Gateway to Technology Magnet, and achieved Honor Roll with Perfect Attendance.";
    }
    if (lowerInput.includes("award") || lowerInput.includes("achievement")) {
      return "I've achieved several honors including ranking as Cadet Corporal in JROTC, Honor Roll, Perfect Attendance, SERV Safe Food Handlers Certificate, and I volunteer at Glory Gospel Church.";
    }
    return "Hi! I'm Collins Onokala, a Computer Science student passionate about IT and software development. Ask me about my skills, experience, education, or how to contact me!";
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    try {
      await submitContact({
        name: formData.get("name") as string,
        email: formData.get("email") as string,
        message: formData.get("message") as string,
      });
      toast.success("Message sent successfully!");
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="loading-screen">
        <div className="pixel-loader"></div>
        <p>Loading Portfolio...</p>
      </div>
    );
  }

  return (
    <div className="portfolio-container">
      <div className="stars"></div>
      <div className="horizon-bg"></div>
      
      {/* Navigation */}
      <nav className="nav-bar">
        <div className="nav-brand">Collins Onokala</div>
        <div className="nav-links">
          {["home", "about", "projects", "resume", "contact"].map((section) => (
            <button
              key={section}
              className={`nav-link ${activeSection === section ? "active" : ""}`}
              onClick={() => setActiveSection(section)}
            >
              {section.charAt(0).toUpperCase() + section.slice(1)}
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content */}
      <main className="main-content">
        {activeSection === "home" && <HomeSection setActiveSection={setActiveSection} />}
        {activeSection === "about" && <AboutSection />}
        {activeSection === "projects" && <ProjectsSection />}
        {activeSection === "resume" && <ResumeSection resumeUrl={getResumeUrl || null} />}
        {activeSection === "contact" && <ContactSection onSubmit={handleContactSubmit} />}
      </main>

      {/* Enhanced Chatbot */}
      <div className={`chatbot ${isChatOpen ? "open" : ""}`}>
        <div className="chat-header" onClick={() => setIsChatOpen(!isChatOpen)}>
          <div className="chat-header-content">
            <span className="chat-avatar">🤖</span>
            <div className="chat-header-text">
              <span className="chat-title">Collins AI Assistant</span>
              <span className="chat-subtitle">Ask about my background!</span>
            </div>
          </div>
          <span className="chat-toggle">{isChatOpen ? "−" : "+"}</span>
        </div>
        {isChatOpen && (
          <div className="chat-content">
            <div className="chat-messages">
              {messages.length === 0 && (
                <div className="welcome-message">
                  <p>👋 Hi! I'm Collins' AI assistant. Ask me about:</p>
                  <ul>
                    <li>• Technical skills & expertise</li>
                    <li>• Work experience</li>
                    <li>• Education & achievements</li>
                    <li>• Contact information</li>
                  </ul>
                </div>
              )}
              {messages.slice().reverse().map((msg, idx) => (
                <div key={idx} className={`message ${msg.sender}`}>
                  <div className="message-avatar">
                    {msg.sender === 'user' ? '👤' : '🤖'}
                  </div>
                  <div className="message-content">{msg.content}</div>
                </div>
              ))}
            </div>
            <form onSubmit={handleChatSubmit} className="chat-input-form">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about my skills, experience, or background..."
                className="chat-input"
              />
              <button type="submit" className="chat-send">
                <span>Send</span>
                <span className="send-icon">→</span>
              </button>
            </form>
          </div>
        )}
      </div>

      <Toaster position="top-right" />
    </div>
  );
}

function HomeSection({ setActiveSection }: { setActiveSection: (section: string) => void }) {
  return (
    <section className="section home-section">
      <div className="hero-content">
        <h1 className="hero-title">
          <span className="pixel-text">Collins Onokala</span>
        </h1>
        <p className="hero-subtitle">Computer Science Senior & IT Enthusiast</p>
        <p className="hero-description">
          Hard-working College Senior passionate about computer software, database development, 
          and Internet of Things. Eager to contribute to IT and computer field innovations.
        </p>
        <div className="hero-buttons">
          <a href="mailto:Onokalacollins17@gmail.com" className="btn btn-primary">
            Email Me
          </a>
          <button className="btn btn-secondary" onClick={() => {
            setActiveSection("contact");
          }}>
            Get In Touch
          </button>
        </div>
        
        {/* QR Code */}
        <div className="qr-section">
          <div className="qr-code">
            <canvas id="qr-canvas" width="120" height="120"></canvas>
          </div>
          <p className="qr-label">Scan to view portfolio</p>
        </div>
      </div>
    </section>
  );
}

function AboutSection() {
  const skills = [
    { category: "Technical Support", items: ["Troubleshooting", "Configuring OS's", "Client Host Configuration", "Networking"] },
    { category: "Programming", items: ["Java", "Oracle SQL", "Database Development", "Software Development"] },
    { category: "Microsoft Office", items: ["Word (6+ years)", "PowerPoint (6+ years)", "Excel", "Data Collection"] },
    { category: "Digital Marketing", items: ["Search Engine Optimization", "Google Analytics", "Web Technologies"] }
  ];

  return (
    <section className="section about-section">
      <h2 className="section-title">About Me</h2>
      <div className="about-content">
        <div className="about-text">
          <p>
            I'm a hard-working and determined College Senior at Bowie State University with a strong 
            interest in computer software and database development. I have extensive knowledge of computer 
            technology and Internet of Things background, making me eager to work in the IT or computer field.
          </p>
          <p>
            My expertise spans across technical support, programming languages, and Microsoft Office Suite 
            with over 6 years of experience. I'm organized, a team player, and passionate about leveraging 
            technology to solve real-world problems.
          </p>
        </div>
        
        <div className="skills-grid">
          {skills.map((skillGroup, idx) => (
            <div key={idx} className="skill-group">
              <h3 className="skill-category">{skillGroup.category}</h3>
              <div className="skill-items">
                {skillGroup.items.map((skill, skillIdx) => (
                  <span key={skillIdx} className="skill-tag">{skill}</span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="experience-timeline">
          <h3>Professional Experience</h3>
          <div className="timeline-item">
            <div className="timeline-date">Nov 2023</div>
            <div className="timeline-content">
              <h4>Front Desk Support - Amazon</h4>
              <p>Managed office operations and clerical support. Monitored office supplies to ensure efficiency.</p>
            </div>
          </div>
          <div className="timeline-item">
            <div className="timeline-date">Aug 2021</div>
            <div className="timeline-content">
              <h4>Mobile Communications Assistant - Future Care</h4>
              <p>Drafted and managed internal communications, website content, and mass media. Assisted senior leadership in conveying strategies and messages while maintaining effective communication with clients, families, and staff.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ProjectsSection() {
  const projects = [
    {
      title: "Database Management System",
      description: "Developed a comprehensive database solution using Oracle SQL for efficient data storage and retrieval. Implemented proper indexing, query optimization, and data integrity constraints.",
      tech: ["Oracle SQL", "Database Design", "Query Optimization", "Data Modeling"],
      features: ["Data Integrity", "Performance Optimization", "Backup & Recovery", "User Access Control"]
    },
    {
      title: "IT Support Automation",
      description: "Created automated solutions for common technical support tasks including OS configuration, client host setup, and network troubleshooting procedures.",
      tech: ["System Administration", "Networking", "Automation Scripts", "Troubleshooting"],
      features: ["Automated Diagnostics", "Configuration Management", "Network Monitoring", "Issue Resolution"]
    },
    {
      title: "SEO Analytics Dashboard",
      description: "Built a comprehensive dashboard using Google Analytics to track website performance, user engagement, and search engine optimization metrics for improved digital presence.",
      tech: ["Google Analytics", "SEO", "Data Analysis", "Web Technologies"],
      features: ["Performance Tracking", "SEO Metrics", "User Behavior Analysis", "Reporting Tools"]
    },
    {
      title: "IoT Device Management",
      description: "Developed a system for managing and monitoring Internet of Things devices, including data collection, device configuration, and real-time status monitoring.",
      tech: ["IoT", "Device Management", "Data Collection", "Monitoring"],
      features: ["Real-time Monitoring", "Device Configuration", "Data Analytics", "Alert System"]
    }
  ];

  return (
    <section className="section projects-section">
      <h2 className="section-title">Projects & Experience</h2>
      <div className="projects-grid">
        {projects.map((project, idx) => (
          <div key={idx} className="project-card">
            <h3 className="project-title">{project.title}</h3>
            <p className="project-description">{project.description}</p>
            <div className="project-tech">
              {project.tech.map((tech, techIdx) => (
                <span key={techIdx} className="tech-tag">{tech}</span>
              ))}
            </div>
            <div className="project-features">
              <h4>Key Features:</h4>
              <ul>
                {project.features.map((feature, featureIdx) => (
                  <li key={featureIdx}>{feature}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function ResumeSection({ resumeUrl }: { 
  resumeUrl: string | null;
}) {
  const [qrCanvas, setQrCanvas] = useState<string>("");

  useEffect(() => {
    const generateResumeQR = async () => {
      try {
        const canvas = document.createElement('canvas');
        await QRCode.toCanvas(canvas, `${window.location.origin}#resume`, {
          width: 100,
          margin: 1,
          color: {
            dark: '#00ff41',
            light: '#ffffff'
          }
        });
        setQrCanvas(canvas.toDataURL());
      } catch (error) {
        console.error('Error generating resume QR code:', error);
      }
    };
    
    generateResumeQR();
  }, []);

  const downloadTextResume = () => {
    const resumeContent = `
COLLINS ONOKALA
Computer Science Senior & IT Enthusiast
443-345-6349 • Onokalacollins17@gmail.com

PROFESSIONAL SUMMARY
Hard-working and determined College Senior interested in computer software and database development. 
Has knowledge of computer technology and the Internet of Things background. Eager to work in an IT or computer field.

AREAS OF EXPERTISE
• Technical Support          • Microsoft Office
• Programming languages      • Java
• Configuring and Installing OS's
• Configuring Client host machines
• Oracle SQL                 • Networking
• Troubleshooting           • Organized
• Team Player               • Microsoft Word (6+ years)
• PowerPoint (6+ years)     • Excel
• Data collection           • Search Engine Optimization
• Google Analytics

PROFESSIONAL EXPERIENCE

Front Desk Support | Amazon | November 2023
• Managed office operations and clerical support
• Monitored office supplies to ensure efficiency

Mobile Communications Assistant | Future Care | August 2021
• Drafted and managed internal communications, website content, and mass media
• Assisted senior leadership in conveying strategies and messages, while maintaining effective communication with clients, families, and staff

EDUCATION
• Bowie State University (Undergraduate)
• Milford Mill Academy (High School Diploma)

ACTIVITIES, INTERESTS, AND AWARDS
• Ranked Cadet Private, Cadet Private First Class, and Cadet Corporal
• Junior Reserve Officers' Training Corps
• Project Lead The Way Gateway to Technology Magnet (P.L.T.W)
• Avid
• SERV Safe Food Handlers Test Certificate
• Volunteer, Glory Gospel Church
• Honor Roll
• Perfect Attendance

Portfolio: ${window.location.origin}
    `;

    const blob = new Blob([resumeContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Collins_Onokala_Resume.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <section className="section resume-section">
      <h2 className="section-title">Resume</h2>
      <div className="resume-content">
        <div className="resume-preview">
          <div className="resume-header">
            <div className="resume-header-content">
              <div>
                <h3>Collins Onokala</h3>
                <p>Computer Science Senior & IT Enthusiast</p>
                <p>443-345-6349 • Onokalacollins17@gmail.com</p>
              </div>
              {qrCanvas && (
                <div className="resume-qr">
                  <img src={qrCanvas} alt="Resume QR Code" />
                  <p>Scan for resume</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="resume-section-item">
            <h4>Professional Summary</h4>
            <p>Hard-working and determined College Senior interested in computer software and database development. Has knowledge of computer technology and the Internet of Things background. Eager to work in an IT or computer field.</p>
          </div>

          <div className="resume-section-item">
            <h4>Areas of Expertise</h4>
            <div className="expertise-grid">
              <ul>
                <li>Technical Support</li>
                <li>Programming languages</li>
                <li>Configuring and Installing OS's</li>
                <li>Oracle SQL</li>
                <li>Troubleshooting</li>
                <li>Team Player</li>
              </ul>
              <ul>
                <li>Microsoft Office</li>
                <li>Java</li>
                <li>Networking</li>
                <li>Organized</li>
                <li>Microsoft Word (6+ years)</li>
                <li>PowerPoint (6+ years)</li>
              </ul>
              <ul>
                <li>Excel</li>
                <li>Data collection</li>
                <li>Search Engine Optimization</li>
                <li>Google Analytics</li>
              </ul>
            </div>
          </div>

          <div className="resume-section-item">
            <h4>Professional Experience</h4>
            <div className="experience-item">
              <h5>Front Desk Support | Amazon | November 2023</h5>
              <ul>
                <li>Managed office operations and clerical support</li>
                <li>Monitored office supplies to ensure efficiency</li>
              </ul>
            </div>
            <div className="experience-item">
              <h5>Mobile Communications Assistant | Future Care | August 2021</h5>
              <ul>
                <li>Drafted and managed internal communications, website content, and mass media</li>
                <li>Assisted senior leadership in conveying strategies and messages</li>
                <li>Maintained effective communication with clients, families, and staff</li>
              </ul>
            </div>
          </div>

          <div className="resume-section-item">
            <h4>Education</h4>
            <ul>
              <li><strong>Bowie State University</strong> - Undergraduate</li>
              <li><strong>Milford Mill Academy</strong> - High School Diploma</li>
            </ul>
          </div>

          <div className="resume-section-item">
            <h4>Activities, Interests, and Awards</h4>
            <ul>
              <li>Ranked Cadet Private, Cadet Private First Class, and Cadet Corporal</li>
              <li>Junior Reserve Officers' Training Corps</li>
              <li>Project Lead The Way Gateway to Technology Magnet (P.L.T.W)</li>
              <li>SERV Safe Food Handlers Test Certificate</li>
              <li>Volunteer, Glory Gospel Church</li>
              <li>Honor Roll & Perfect Attendance</li>
            </ul>
          </div>
        </div>

        <div className="resume-actions">
          <button onClick={downloadTextResume} className="btn btn-primary">
            📄 Download Text Resume
          </button>
          
          {resumeUrl && (
            <a href={resumeUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
              📎 Download Uploaded Resume
            </a>
          )}
        </div>
      </div>
    </section>
  );
}

function ContactSection({ onSubmit }: { onSubmit: (e: React.FormEvent) => void }) {
  return (
    <section className="section contact-section">
      <h2 className="section-title">Get In Touch</h2>
      <div className="contact-content">
        <div className="contact-info">
          <h3>Let's Connect!</h3>
          <p>
            I'm actively seeking opportunities in IT and computer fields. 
            Whether you have questions about my experience or want to discuss potential opportunities, 
            I'd love to hear from you!
          </p>
          <div className="contact-links">
            <a href="tel:443-345-6349" className="contact-link">
              📞 443-345-6349
            </a>
            <a href="mailto:Onokalacollins17@gmail.com" className="contact-link">
              📧 Onokalacollins17@gmail.com
            </a>
          </div>
        </div>

        <form onSubmit={onSubmit} className="contact-form">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input type="text" id="name" name="name" required className="form-input" />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" required className="form-input" />
          </div>
          <div className="form-group">
            <label htmlFor="message">Message</label>
            <textarea id="message" name="message" required className="form-textarea" rows={5}></textarea>
          </div>
          <button type="submit" className="btn btn-primary">Send Message</button>
        </form>
      </div>
    </section>
  );
}
