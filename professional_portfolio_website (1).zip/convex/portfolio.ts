import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getChatMessages = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("messages").order("desc").take(50);
  },
});

export const sendMessage = mutation({
  args: {
    content: v.string(),
    sender: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("messages", {
      content: args.content,
      sender: args.sender,
      timestamp: Date.now(),
    });
  },
});

export const submitContact = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("contacts", {
      name: args.name,
      email: args.email,
      message: args.message,
      timestamp: Date.now(),
    });
  },
});

export const getContacts = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("contacts").order("desc").collect();
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const getResumeUrl = query({
  args: {},
  handler: async (ctx) => {
    // Get the most recent resume upload
    const resume = await ctx.db.query("resumes").order("desc").first();
    if (!resume) return null;
    
    return await ctx.storage.getUrl(resume.storageId);
  },
});

export const saveResumeInfo = mutation({
  args: {
    storageId: v.id("_storage"),
    filename: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("resumes", {
      storageId: args.storageId,
      filename: args.filename,
      uploadedAt: Date.now(),
    });
  },
});
